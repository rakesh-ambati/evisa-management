package com.klef.jfsd.service;

public interface CustomerService {

}
