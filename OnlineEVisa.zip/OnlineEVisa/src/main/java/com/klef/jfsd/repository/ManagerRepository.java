package com.klef.jfsd.repository;

import org.springframework.data.repository.CrudRepository;

import com.klef.jfsd.model.Manager;

public interface ManagerRepository extends CrudRepository<Manager, String>
{

}
