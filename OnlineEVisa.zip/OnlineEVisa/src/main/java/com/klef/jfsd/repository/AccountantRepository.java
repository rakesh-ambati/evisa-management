package com.klef.jfsd.repository;

public interface AccountantRepository {

}
