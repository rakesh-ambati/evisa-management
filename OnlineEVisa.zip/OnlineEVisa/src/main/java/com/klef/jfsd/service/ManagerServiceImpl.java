package com.klef.jfsd.service;

public class ManagerServiceImpl implements ManagerService
{

}
