package com.klef.jfsd.service;

public interface AccountantService {

}
